using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

public static class NativeWindowStyle {
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr windowHandle, int index);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr windowHandle, int index, int newLong);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr windowHandle, IntPtr insertAfterHandle, int x, int y, int width, int height, uint flags);
}

public static class ForegroundWindowControl {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr windowHandle);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr windowHandle);
}

// Reads the real keyboard even though the strip itself never has the focus.
public static class KeyboardModifierState {
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int virtualKey);
    [DllImport("user32.dll")] private static extern short GetKeyState(int virtualKey);
    private const int ShiftVirtualKey = 0x10;
    private const int CapsLockVirtualKey = 0x14;
    public static bool IsShiftHeld() { return (GetAsyncKeyState(ShiftVirtualKey) & 0x8000) != 0; }
    public static bool IsCapsLockOn() { return (GetKeyState(CapsLockVirtualKey) & 0x1) != 0; }
}

// Types text into whichever app has the keyboard focus, as if it came from the keyboard.
public static class UnicodeTextTyper {
    [StructLayout(LayoutKind.Sequential)]
    private struct KeyboardInput { public ushort VirtualKey; public ushort ScanCode; public uint Flags; public uint Time; public IntPtr ExtraInfo; }
    // Never sent; only here so the union has the size Windows expects (mouse input is the largest member).
    [StructLayout(LayoutKind.Sequential)]
    private struct MouseInput { public int X; public int Y; public uint MouseData; public uint Flags; public uint Time; public IntPtr ExtraInfo; }
    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion { [FieldOffset(0)] public MouseInput Mouse; [FieldOffset(0)] public KeyboardInput Keyboard; }
    [StructLayout(LayoutKind.Sequential)]
    private struct Input { public uint Type; public InputUnion Data; }

    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint inputCount, Input[] inputs, int inputSize);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int virtualKey);

    private const uint KeyboardInputType = 1;
    private const uint KeyUpEventFlag = 0x2;
    private const uint UnicodeEventFlag = 0x4;
    private const int ControlVirtualKey = 0x11;
    private const ushort LeftControlVirtualKey = 0xA2;
    private const ushort RightControlVirtualKey = 0xA3;

    private static Input NewKeyboardInput(ushort virtualKey, ushort scanCode, uint flags) {
        Input input = new Input();
        input.Type = KeyboardInputType;
        input.Data.Keyboard.VirtualKey = virtualKey;
        input.Data.Keyboard.ScanCode = scanCode;
        input.Data.Keyboard.Flags = flags;
        return input;
    }

    // Returns whether Windows accepted every key event.
    public static bool TypeText(string text) {
        var inputs = new System.Collections.Generic.List<Input>();
        // Ctrl is still held after Ctrl+C in keyboard mode; release it so apps don't read the character as a shortcut and drop it.
        bool isControlHeld = (GetAsyncKeyState(ControlVirtualKey) & 0x8000) != 0;
        if (isControlHeld) {
            inputs.Add(NewKeyboardInput(LeftControlVirtualKey, 0, KeyUpEventFlag));
            inputs.Add(NewKeyboardInput(RightControlVirtualKey, 0, KeyUpEventFlag));
        }
        foreach (char textCharacter in text) {
            inputs.Add(NewKeyboardInput(0, textCharacter, UnicodeEventFlag));
            inputs.Add(NewKeyboardInput(0, textCharacter, UnicodeEventFlag | KeyUpEventFlag));
        }
        uint acceptedInputCount = SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf(typeof(Input)));
        return acceptedInputCount == inputs.Count;
    }
}

// Detects Right Alt (AltGr) being pressed and released with no other key in between.
public static class RightAltTapListener {
    private delegate IntPtr LowLevelKeyboardProc(int code, IntPtr messageType, IntPtr keyInfoPointer);

    [StructLayout(LayoutKind.Sequential)]
    private struct KeyboardHookInfo { public int VirtualKeyCode; public int ScanCode; public int Flags; public int Time; public IntPtr ExtraInfo; }

    [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr SetWindowsHookEx(int hookType, LowLevelKeyboardProc callback, IntPtr module, int threadId);
    [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr messageType, IntPtr keyInfoPointer);
    [DllImport("kernel32.dll")] private static extern IntPtr GetModuleHandle(string moduleName);
    [DllImport("user32.dll")] private static extern void keybd_event(byte virtualKey, byte scanCode, int flags, IntPtr extraInfo);

    private const int LowLevelKeyboardHookType = 13;
    private const int KeyDownMessage = 0x100;
    private const int SystemKeyDownMessage = 0x104;
    private const byte RightAltVirtualKey = 0xA5;
    private const byte RightAltScanCode = 0x38;
    private const byte UnassignedMaskVirtualKey = 0xE8;
    // Marks the key events this hook injects itself so it can ignore them.
    private static readonly IntPtr OwnInjectionMarker = (IntPtr)0x46524B59;
    private const int ExtendedKeyEventFlag = 0x1;
    private const int KeyUpEventFlag = 0x2;

    private static readonly LowLevelKeyboardProc callbackKeptAliveForGarbageCollector = OnKeyboardEvent;
    private static bool isRightAltDown;
    private static bool wasOtherKeyPressedWhileRightAltDown;

    public static volatile bool WasTapped;

    public static void Start() {
        IntPtr hookHandle = SetWindowsHookEx(LowLevelKeyboardHookType, callbackKeptAliveForGarbageCollector, GetModuleHandle(null), 0);
        if (hookHandle == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not install the Right Alt keyboard hook");
    }

    private static IntPtr OnKeyboardEvent(int code, IntPtr messageType, IntPtr keyInfoPointer) {
        if (code >= 0) {
            KeyboardHookInfo keyInfo = (KeyboardHookInfo)Marshal.PtrToStructure(keyInfoPointer, typeof(KeyboardHookInfo));
            bool isOwnInjection = keyInfo.ExtraInfo == OwnInjectionMarker;
            int message = messageType.ToInt32();
            bool isKeyDown = message == KeyDownMessage || message == SystemKeyDownMessage;
            if (!isOwnInjection && keyInfo.VirtualKeyCode == RightAltVirtualKey) {
                if (isKeyDown && !isRightAltDown) {
                    isRightAltDown = true;
                    wasOtherKeyPressedWhileRightAltDown = false;
                } else if (!isKeyDown) {
                    bool wasTap = isRightAltDown && !wasOtherKeyPressedWhileRightAltDown;
                    isRightAltDown = false;
                    if (wasTap) {
                        WasTapped = true;
                        // Replay the release behind a dummy key so the focused app doesn't see a lone Alt tap and open its menu bar.
                        keybd_event(UnassignedMaskVirtualKey, 0, 0, OwnInjectionMarker);
                        keybd_event(UnassignedMaskVirtualKey, 0, KeyUpEventFlag, OwnInjectionMarker);
                        keybd_event(RightAltVirtualKey, RightAltScanCode, ExtendedKeyEventFlag | KeyUpEventFlag, OwnInjectionMarker);
                        return (IntPtr)1;
                    }
                }
            } else if (!isOwnInjection && isKeyDown && isRightAltDown) {
                wasOtherKeyPressedWhileRightAltDown = true;
            }
        }
        return CallNextHookEx(IntPtr.Zero, code, messageType, keyInfoPointer);
    }
}
